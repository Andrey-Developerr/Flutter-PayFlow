class HomeController {
  var curretPage = 0;

  void setPage(int index) {
    curretPage = index;
  }
}
