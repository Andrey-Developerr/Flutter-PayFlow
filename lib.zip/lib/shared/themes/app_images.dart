class AppImages {
  static const logoFull = "assets/images/logofull.png";
  static const logomini = "assets/images/logomini.png";
  static const union = "assets/images/union.png";
  static const person = "assets/images/person.png";
  static const google = "assets/images/google.png";
}
